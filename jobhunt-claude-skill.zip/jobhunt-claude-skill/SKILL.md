---
name: "jobhunt"
description: Personal job-hunt copilot for a 2027-batch fresher. Searches the user's chosen job and internship platforms (LinkedIn, Naukri, Internshala, Wellfound, YC, Handshake, Forage, UN/OECD/UNICEF and more), lists only OPEN roles the user is eligible for, scores them 1-10 against their master resume, grills the user on what is missing to survive screening, then writes a tailored resume per company, logs each application in an Excel tracker, and maintains a consistency dashboard (a day runs 4AM-3:59AM IST). Has two subskills - "companypage" (scan official career pages the user names) and "fundingcompanies" (find recently funded or mass-hiring companies). Use this skill whenever the user says jobhunt, job hunt, find me jobs or internships, check job sites, tailor my resume for a company, log or track my applications, show my application dashboard, companypage, or fundingcompanies, even if they do not name the skill.
---

# JobHunt

Run the user's job search as a staged pipeline. The user is a 2027 graduate (confirm from the master resume) who wants breadth across platforms, honest scoring, honest feedback, and a record of their consistency. Honesty matters more than comfort here: a flattering score or a padded resume costs the user real interviews, so never inflate either.

## Routing

- User says **companypage** (or asks to scan specific career pages) → read `references/companypage.md`, run it, then continue the pipeline from Stage 3.
- User says **fundingcompanies** (or asks about funded, hiring-spree, or new-client companies) → read `references/fundingcompanies.md`, run it, then continue from Stage 3.
- User asks only to log applications or see the dashboard → jump to Stage 7 (read `references/tracker.md`).
- Otherwise run the full pipeline below, starting at Stage 0.

Today's date and time come from the conversation context. Treat all times as IST.

## Stage 0: Inputs

1. **Master resume.** The user's resume is stored in this skill at `assets/master_resume.md` (a faithful transcription; `assets/master_resume.pdf` is the original and holds the exact GitHub and LinkedIn links). Read the `.md` file and use it as the profile. If the user uploaded a newer resume this run, that upload overrides the stored one for this session; mention that the stored copy is unchanged and offer to have it updated in the skill. Don't ask for the resume when the stored one exists. Instead, confirm in one short line ("Using your stored master resume. Anything new since, like a project or certification?") and carry on. If the `.md` is missing, ask for an upload and wait.
2. **Tracker.** Ask once whether they have an existing `JobHunt_Tracker.xlsx` to upload. If yes, it gets extended in Stage 7; if not, a new one is created.
3. **Role focus.** Default to every field the resume plausibly fits. If the user names keywords or fields, narrow to those.

## Stage 1: Platform picker

Show the platform list from `references/platforms.md` as a selectable board with **Select all** as the first option, then each platform. The `ask_user_input_v0` tool only allows 12 options, so instead:

- Preferred: render an interactive checklist with the visualizer (load its `interactive` module first). Put "Select all" first (ticking it ticks everything), list every platform with a checkbox, and add a Submit button that calls `sendPrompt` with the chosen names.
- Fallback if the widget is unavailable: a numbered list; the user replies "all" or numbers like "1, 4, 7-9".

Do not narrate the tooling. Say something like "Pick the platforms to check" and show the board. If the user picks "Select all", cover every platform, no shortcuts.

## Stage 2: Search, verify, and the raw table

Go through each selected platform one by one, using `references/platforms.md` for how to search it, how to tell whether a listing is open, and its access quirks. Search each platform separately with several differently-worded queries, because one combined query returns shallow results. Open the actual posting with `web_fetch` whenever possible.

**Eligibility filter.** Keep a role only if the 2027 batch (or a student of age 18+) can apply, i.e. the posting is open to 2027 graduates, or to any student or anyone 18+ with no graduation-year restriction. Remote, onsite, hybrid, online, paid, and stipend roles all qualify. Drop roles restricted to other batches, experienced hires, specific degree levels the user lacks, or nationalities and work permits the user can't meet. If eligibility is unclear, keep the row and mark it "Eligibility unclear: check".

**Open-only rule (critical).** Never present a closed application as available. A role is closed if its deadline is before today, the page says closed, expired, filled, or no longer accepting applications, or the page 404s. If you cannot open or confirm a posting (login walls, blocked pages), do not put it in the main table. List it separately under "Couldn't verify" with the link and the reason, so the user can check it by hand.

**Raw table (no scoring yet).** One row per verified open role, numbered with a single running S.No that carries through all later stages:

| S.No | Company | Role | Platform | Type | Location | Mode | Pay / Stipend | Eligibility (as stated) | Deadline | Link | Verified on |

- Type: Job, Internship, Micro-internship, Virtual experience (not employment), or Volunteer.
- Mode: Remote, Onsite, or Hybrid.
- Write "Not stated" instead of guessing any field.
- Flag fee-charging programs in the Pay column ("Participant fee: check"), since the user shouldn't be surprised by that.

After the table add a short **coverage note**: for each selected platform, how many open roles were found and any access limitation (for example "Handshake needs a university login, so I could not read it"). Be straight about gaps; completeness cannot be guaranteed on login-walled sites.

Then ask if they want scoring.

## Stage 3: Scoring

When the user says go, score every role in the raw table against the master resume out of 10, using this weighting: skills and stack match 40%, relevant experience and projects 25%, field and role fit 15%, eligibility certainty 10%, practical factors (location, pay, mode) 10%. Verdicts: **8-10 Best match**, **5-7 Average match**, **1-4 Worst match**. Don't round up to be nice; a 5 is a 5.

| S.No | Company | Role | Score /10 | Verdict | Why (one line) | Biggest gap |

Sort by score descending, but keep the original S.No so the user can refer back. Then ask which S.Nos they want to apply to.

## Stage 4: Screening grill (before any resume is written)

For each chosen role, open the full job description and extract what the screen will actually test: required skills, tools, keywords an ATS will search for, certifications, domain exposure, location or work-authorization constraints, and anything phrased as "must have".

Compare that against the master resume and be blunt. Say plainly, per company, something like: "As written, your resume will probably not pass the screen at X because ..." Then ask pointed questions for the exact things that would change that: a certification, a tool used in a project, a measurable result, a relevant course, a portfolio or GitHub link, a competition, a past internship task. Follow these rules:

- Ask about specifics, not "anything else?". Name the missing item ("Do you have anything with Kubernetes, even a deployed side project?").
- Push back on vague answers. "I know a bit of SQL" gets "Where did you use it, on what data, with what result?" Do not accept a claim you can't turn into a truthful resume line.
- Don't be a yes-man. If the gap is large enough that the application is a long shot, say so, and say what it would take to close the gap.
- Deduplicate: ask shared questions once across all chosen roles, then company-specific ones. Prioritise by impact on passing the screen; around 5-7 questions per company at most.
- Never invent or suggest the user claim things they haven't done.

Wait for answers. One follow-up round is fine if answers are thin. Then proceed with whatever the user has confirmed, and note gaps that remain.

## Stage 5: Tailored resumes

Read `references/resume-tailoring.md` and the docx skill (`/mnt/skills/public/docx/SKILL.md`) before creating files. Produce one `.docx` per company (and a PDF copy), named `Name_Company_Role`. Each must use only facts from the master resume or confirmed in the grill. After generating, give the user a short per-company honest verdict: what the resume now covers well and what is still weak.

## Stage 6: Present files

Put outputs in `/mnt/user-data/outputs/` and call `present_files`. Keep the closing message short.

## Stage 7: Tracker and dashboard

Read `references/tracker.md`. Log every resume generated in this session to `JobHunt_Tracker.xlsx` (extending the user's file if they uploaded one), recalculate, and present it. Then ask one question: did they actually submit all of these? Any they didn't get marked "Not submitted" so the dashboard stays honest. Remind them to upload the latest tracker next session because skills don't remember between chats.
