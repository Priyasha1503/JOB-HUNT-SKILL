# JobHunt: an AI job-search agent (Claude Skill)

A Claude agent skill I designed to run my internship search for the 2027 batch, from finding open roles to tailoring resumes and tracking applications.

## What it does

The skill runs as a staged pipeline:

| Stage | What happens |
|---|---|
| 0. Inputs | Loads my master resume as the single source of truth |
| 1. Platform picker | I choose which job platforms to search |
| 2. Search & verify | Searches each platform, opens each posting, keeps only **open** roles I'm **eligible** for |
| 3. Scoring | Scores each role 1–10 against my resume with a weighted rubric (skills 40%, experience 25%, role fit 15%, eligibility 10%, practical factors 10%) |
| 4. Screening grill | Before writing anything, questions me on every gap the screen will test |
| 5. Tailored resumes | Writes one resume per company using only verified facts |
| 7. Tracker | Logs applications to an Excel tracker with a consistency dashboard |

Two sub-skills: `companypage` (scan official career pages) and `fundingcompanies` (find recently funded or hiring companies).

## Guardrails (the hard part)

LLMs tend to make a candidate look better than they are and to list postings that have already closed. The skill prevents both:

- **Open-only rule:** a role is shown only if its posting was opened and confirmed open; anything that can't be verified goes to a separate "Couldn't verify" list.
- **No invented facts:** resumes may use only the master resume or answers I confirmed. No invented skills, tools, metrics, employers or dates.
- **Screening grill:** the agent must question me on specific gaps and push back on vague answers before it writes a resume.
- **Honest scoring:** no rounding scores up.

## Files

```
SKILL.md                     # main agent instructions and pipeline
references/platforms.md      # how to search and verify each platform
references/resume-tailoring.md
references/tracker.md        # tracker rules (a "day" runs 4 AM–3:59 AM IST)
references/companypage.md    # sub-skill: official career pages
references/fundingcompanies.md
scripts/tracker.py           # Python tool the agent calls to log applications and rebuild the dashboard
```

## Using it

Add the folder as a skill in Claude, then say "jobhunt". The skill expects a master resume at `assets/master_resume.md`, which is not included here because it contains personal details.

## Author

Priyasha Sabbavarapu, B.Tech CSE (2027), Malla Reddy Engineering College for Women, Hyderabad.
