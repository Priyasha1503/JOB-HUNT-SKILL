# Tracker and dashboard

One Excel file, `JobHunt_Tracker.xlsx`, holds everything with three sheets:

- **Dashboard**: stats (total applications, days applied, days missed, consistency %, current and longest streak, best day, average per active day), a week-by-week calendar (red = missed day, amber = today not applied yet, green = applied, darker green = 3+ applications), and a weekly bar chart.
- **Applications**: one row per application (S.No, company, role, platform, applied date and time in IST, tracker day, match score and label, status, resume file name, link, notes).
- **Daily Log**: one row per day since the hunt started, with application count, Applied/Missed/Pending status, and streak.

## The day rule

A day runs from 4:00 AM to 3:59 AM IST the next morning. The sheet subtracts 4 hours from each timestamp before taking its date, so an application logged at 2:30 AM on the 18th counts toward the 17th. The dashboard's "today" uses the same rule.

## Running it

The script lives at `scripts/tracker.py` in this skill. Steps:

1. If the user uploaded a tracker, copy it to `/mnt/user-data/outputs/JobHunt_Tracker.xlsx` so the script extends it. If they didn't, the script creates a new one at that path.
2. Write a JSON list of this session's applications to a temp file. Each object:
   `company`, `role`, `platform`, `link`, `match_score` (number from Stage 3), `resume_file` (the file name produced), optional `notes`. Leave out `applied_at` to stamp the current IST time.
3. Run:
   `python scripts/tracker.py --file /mnt/user-data/outputs/JobHunt_Tracker.xlsx --add /tmp/new_rows.json`
4. Recalculate so values are cached and verify no errors:
   `python /mnt/skills/public/xlsx/scripts/recalc.py /mnt/user-data/outputs/JobHunt_Tracker.xlsx 60`
   If it reports errors, fix and rerun before presenting.
5. Call `present_files` on the tracker.

## Status updates

Statuses are Applied, Not submitted, Interview, Rejected, Offer. "Not submitted" rows are excluded from every count, which keeps the dashboard honest. After presenting, ask the user which of this session's applications they actually submitted. For any they didn't, run:

`python scripts/tracker.py --file <tracker> --set-status "<S.No>:Not submitted"`

(repeat the flag per row), recalc, and present again. The same flag handles later updates like `"4:Interview"`, when the user returns with news.

## Limits to mention once

- Skills don't remember between chats, so the user must upload their latest tracker each session. Remind them at the end.
- The dashboard's "today" comes from the clock of the machine opening the file, so it is right when the user opens it in IST.
- The Daily Log covers 400 days and the calendar 52 weeks. That's plenty for a hunt of this kind; tell the user if they approach the limit.
