# fundingcompanies

Find companies that are likely to need new people right now because something just happened: a funding round, a hiring drive, a big client, or a new project. Use this when the user says "fundingcompanies" or asks about funded startups, mass hiring, fresher drives, or companies that just won a client or project.

The logic behind it: money or new work creates headcount pressure. But a signal only suggests hiring, it doesn't prove it. A company that raised a round may be hiring senior engineers only. So every company here must end with a check of what it is actually hiring for.

## Step 1: Ask what signals to look for

Use `ask_user_input_v0` with a multi-select question (a short lead-in line first):

- Recent funding rounds (startups and scaleups)
- Mass or general fresher hiring (campus drives, batch hiring, "hiring 1,000 freshers")
- New client or project wins (contracts, partnerships, expansions)
- All of the above

Then let them add an optional sector or region in their next message, but don't make them. If they don't specify, search broadly and weight toward roles that fit the master resume.

## Step 2: Search for the signals

Default window: the last 90 days from today's date. Use searches phrased around the signal, run separately per signal type:

- Funding: "raises seed", "Series A", "Series B", "funding round" with the month or year, filtered by the user's sector or region when given.
- Mass hiring: "to hire freshers 2027", "campus hiring 2026-27", "mass hiring drive", "fresher batch hiring".
- Client or project wins: "wins contract", "partnership announced", "expands team", "opens new office", "new project".

Use reputable news and company announcements. Read the article itself with `web_fetch` for the details and the date. Do not state a funding amount, investor, date, or hiring number that you didn't read in a source, and don't invent a source.

## Step 3: Verify hiring for each company

For each company that looks promising:

1. Find its official careers page (see `references/companypage.md` for how).
2. Look for roles a 2027 graduate or student can apply to (intern, graduate, associate, entry-level).
3. Apply the same open-only rule and eligibility filter as the main skill. A closed role never goes in the results.

Keep a company in the signal table even if it has no matching open role, but mark it clearly, because it is still useful for the user to know and to reach out to directly. Don't list it in the numbered application table.

## Step 4: Report

First, the signal table (companies, not yet roles):

| Company | Signal | What happened (as sourced) | Date | Source | Careers page | Open roles for me? |

Signal is Funding, Mass hiring, or Client/project. "What happened" is a one-line, sourced summary. "Open roles for me?" is Yes (with count), No, or Couldn't verify.

Second, for companies with open matching roles, the standard raw table from SKILL.md Stage 2, continuing the S.No sequence. Add one honest line about the signal's weight, for example "Funding is 3 weeks old, but the careers page only lists senior roles, so this one is a long shot." Then continue from Stage 3 (scoring) when the user asks.
