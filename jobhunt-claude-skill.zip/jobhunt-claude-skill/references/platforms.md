# Platforms

This is the list shown in the Stage 1 picker, in this order, after "Select all". Company career pages are not on the board: they live in the `companypage` subskill, and funded or mass-hiring companies live in `fundingcompanies`.

Several of these are not job boards. They are virtual experience programs or volunteering. They still belong in the results, but label the Type column honestly so the user doesn't confuse a simulation with a paid role.

## How to check any platform

1. Run several web searches per platform with different wording (for example "2027 batch internship", "fresher 2027", "entry level graduate 2027", "remote internship", plus the user's role keywords), and prefer results from the platform's own domain.
2. Open each candidate posting with `web_fetch`. Read the eligibility, location, pay, and deadline from the posting itself, not from the search snippet.
3. Decide open or closed using the signals below. When a page can't be opened, the posting goes to "Couldn't verify", never into the main table.
4. Many sites are JavaScript-heavy or login-gated. If a listing page returns empty or a login wall, say so in the coverage note rather than guessing what is on it.

Domains below are starting points. Confirm through search, since sites move.

## The list

| # | Platform | Type of listings | Where to look | Notes |
|---|----------|------------------|---------------|-------|
| 1 | LinkedIn | Jobs, internships | linkedin.com/jobs, filter Internship / Entry level, recent | Login wall. Individual public posting pages are sometimes fetchable. Closed if "No longer accepting applications". Check posted date; old reposts are often dead. |
| 2 | Naukri | Jobs, fresher roles | naukri.com | Often blocks fetching. Rely on search results and any posting page that opens. Closed if "expired" or "no longer available". |
| 3 | Y Combinator (startups) | Startup jobs and internships | workatastartup.com, ycombinator.com/jobs | Lists roles per YC company. Check for intern and new-grad roles, then confirm on the company's own careers link. |
| 4 | foundit | Jobs, fresher roles | foundit.in (formerly Monster India) | Same fetch caveats as Naukri. |
| 5 | Wellfound (AngelList) | Startup jobs, internships | wellfound.com/jobs | Heavy login wall. Use search, and confirm against the company's own careers page. |
| 6 | Forage | Virtual job simulations | theforage.com | Free self-paced simulations, not employment, no stipend. Type = Virtual experience. Usually open to join any time, so list the program and note it is a simulation. |
| 7 | Parker Dewey | Micro-internships (paid, short projects) | parkerdewey.com | Student and recent-grad focus, strongly US-oriented. Check location and work-authorization limits. |
| 8 | RippleMatch | Early-career jobs and internships | ripplematch.com | Mostly behind login and US-oriented. Report what is publicly visible and say the rest is gated. |
| 9 | Handshake | Campus jobs and internships | joinhandshake.com | Requires a university-linked account. Claude usually cannot read it. Say so, and offer to evaluate listings the user pastes in. |
| 10 | UN Careers (internships) | UN internships | careers.un.org | Eligibility is strict (typically enrollment or recent-graduate conditions) and differs by posting. Read the posting's eligibility carefully and compare to the user's actual status. Use the posting's deadline. Many are unpaid, so say so. |
| 11 | OECD (internships) | OECD internships | OECD careers / internships pages | Strict eligibility and fixed application windows. Check dates and requirements per posting. |
| 12 | UNICEF (internships) | UNICEF internships | UNICEF careers pages | Strict eligibility. Often unpaid. Check each posting's rules and deadline. |
| 13 | Idealist.org | Nonprofit jobs, internships, volunteering | idealist.org | Use the internship and entry-level filters. Mark volunteering as Type = Volunteer. |
| 14 | Remote Internships | Remote-only internships | Remote-internship boards and searches | The user listed this without a specific site, so treat it as remote-only internship listings found through search. If they have a particular site in mind they can tell you, and you add it. |
| 15 | Internshala | Internships and fresher jobs (India) | internshala.com | Usually fetchable. Shows "Apply by" dates; closed if applications closed or the date passed. Note stipend and whether it is work-from-home. |
| 16 | Catchafire | Skills-based volunteering with nonprofits | catchafire.org | Volunteer, unpaid, project-based. Type = Volunteer. Useful for portfolio material, so say that, but don't present it as a job. |
| 17 | Global Experiences (virtual internships) | Virtual internship programs | Global Experiences / Virtual Internships program pages | Programs are often cohort-based and may charge a participant fee. Always check cost and flag it. Type = Virtual experience. |
| 18 | Acadium | Virtual internships with startups | acadium.com | Check whether a participant fee applies and flag it. Type = Virtual experience. |
| 19 | Bright Network Internship Experience | Free virtual internship programs | brightnetwork.co.uk | UK-oriented, cohort-based with application windows. Check the dates, and the eligibility for international students. Type = Virtual experience. |

## Reporting access limits

Keep a running tally while searching: platform, roles found, roles verified open, and limitation (login wall, blocked, empty page). Use it for the coverage note at the end of Stage 2. A platform with zero results should be reported as zero with the reason, not skipped silently.
