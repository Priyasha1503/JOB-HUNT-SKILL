# Resume tailoring

Goal: for each chosen role, a resume that gets past the screen and still describes the user truthfully. The master resume plus the answers from the Stage 4 grill are the only sources of facts. A resume that overclaims might get an interview and then collapse in it, and it can cost the user the offer, so never stretch the truth.

## What to change per company

- **Headline and summary.** Rewrite for the role, using the company's own language where it's honest. Two lines at most.
- **Skills section.** Reorder so the skills the job description asks for come first. Include a skill only if the user actually has it. Mirror the exact wording the job description uses when the user has that skill (for example "PostgreSQL" rather than "databases"), because ATS filters match on keywords.
- **Projects and experience.** Pick the most relevant ones and lead with them. Reword bullets to emphasise what matters for this role. Cut or shrink what doesn't help.
- **New material from the grill.** Add the certifications, tools, projects, and results the user confirmed. Use their real numbers. If the user gave no number, write the bullet without one rather than inventing a metric.
- **Education, dates, titles, employers.** Never change these.

## Hard rules

- No invented skills, tools, certifications, metrics, employers, or dates. If a requirement isn't met, the resume doesn't claim it. Say so in the verdict instead.
- No keyword stuffing, hidden text, or white-on-white text. ATS and recruiters both penalise it.
- If a fact is ambiguous, ask the user rather than assume.

## Format

- ATS-friendly: single column, standard headings (Summary, Education, Skills, Projects, Experience, Certifications), no tables or text boxes for body content, no images, plain bullets.
- One page, since this is a fresher resume. Go to two only if the content truly earns it.
- Consistent font (Arial or Calibri), 10-11 pt body, clear spacing.
- Keep the master resume's contact details and links. The exact GitHub and LinkedIn URLs are embedded in `assets/master_resume.pdf`; extract them from the PDF (for example with pypdf's link annotations) instead of writing a bare "GitHub" label with no link.

## Files

Read `/mnt/skills/public/docx/SKILL.md` before building. Produce one `.docx` per company named `Name_Company_Role.docx`, and a PDF copy via the docx skill's conversion approach. Save in `/mnt/user-data/outputs/` and present them.

## Honest verdict (in chat, not in the file)

After each resume, give two or three lines:

- What the resume now covers well for this role.
- What is still weak, and how much that is likely to matter at the screen.
- Whether it is worth applying anyway (a long shot is a long shot; say so).

Keep it plain and specific. Don't soften it, and don't turn it into a lecture.
