# companypage

Scan the official career pages of companies the user names, which is the most reliable source for whether a role is actually open. Use this when the user says "companypage", gives company names or career-page URLs, or asks to check a specific company's openings.

## Step 1: Get the targets

Ask the user for the companies, ideally with their career-page URLs. If they give only names, find each company's official careers page through search, and confirm it is the company's own domain or its official applicant-tracking page (Greenhouse, Lever, Workday, Ashby, and similar), not a third-party aggregator. If the user pasted several companies, work through them one at a time.

## Step 2: Read each careers page

1. `web_fetch` the careers page. Look for sections such as Students, Early Careers, Graduates, Interns, Campus, or University.
2. Many career pages load their listings with JavaScript. If the fetch returns an empty shell, try the company's applicant-tracking-system listing URL (often linked from the careers page), or search for the company name with "careers" plus keywords like "intern", "graduate", or "2027". If the listing still can't be read, say so, and put the company in "Couldn't verify" with the link, so the user can look.
3. Open each relevant role's own page and read the eligibility, location, pay, and deadline from it.
4. Apply the same eligibility filter and open-only rule as the main skill (see Stage 2 of SKILL.md): only 2027-batch or 18+ eligible roles, and never a closed role. A role is closed if the deadline has passed, the page says it is closed or filled, or it 404s. Check today's date against any deadline.

## Step 3: Report

Use the raw-table format from SKILL.md Stage 2, with Platform set to "Company page: <company>" and the Link going to the posting. Add a line per company: how many open early-career roles were found, or "No open early-career roles right now." Don't pad an empty company with weak matches.

Continue with SKILL.md from Stage 3 (scoring) when the user asks for it. Keep S.Nos running across everything shown in the conversation so a later pick is unambiguous.
