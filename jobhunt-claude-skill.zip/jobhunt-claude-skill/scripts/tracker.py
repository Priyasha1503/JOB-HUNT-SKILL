#!/usr/bin/env python3
"""JobHunt tracker: append applications and rebuild the consistency dashboard.

Usage:
  python tracker.py --file JobHunt_Tracker.xlsx --add rows.json
  python tracker.py --file JobHunt_Tracker.xlsx --set-status "3:Not submitted" --set-status "5:Interview"
  python tracker.py --file JobHunt_Tracker.xlsx            # just rebuild dashboard

rows.json is a list of objects with keys:
  company, role, platform, link, match_score (number, optional), resume_file,
  notes (optional), status (optional, default "Applied"),
  applied_at (optional ISO string in IST, e.g. "2026-10-17T21:30"; default = now in IST)

If --file exists it is loaded and extended; otherwise a new workbook is created.
Afterwards run the xlsx skill's recalc.py on the file so formula values are cached.

A "tracker day" runs 4:00 AM to 3:59 AM IST the next morning. Every timestamp has
4 hours subtracted before taking its calendar date, so an application at 2:30 AM on
the 18th counts toward the 17th.
"""
import argparse
import json
import os
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

from openpyxl import Workbook, load_workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.datavalidation import DataValidation

FONT = "Arial"
MAXR = 5000          # formula range limit on Applications
LOG_ROWS = 400       # days covered by the Daily Log
WEEKS = 52           # rows in the calendar grid
STATUSES = ["Applied", "Not submitted", "Interview", "Rejected", "Offer"]
APP_HEADERS = ["S.No", "Company", "Role", "Platform", "Applied At (IST)", "Tracker Day",
               "Match Score", "Match Label", "Status", "Resume File", "Link", "Notes"]

HEAD_FILL = PatternFill("solid", start_color="1F3A5F")
HEAD_FONT = Font(name=FONT, bold=True, color="FFFFFF")
BODY_FONT = Font(name=FONT, size=10)
THIN = Side(style="thin", color="D0D0D0")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def now_ist():
    return datetime.now(ZoneInfo("Asia/Kolkata")).replace(tzinfo=None, microsecond=0)


def label_for(score):
    if score in (None, ""):
        return ""
    s = float(score)
    return "Best match" if s >= 8 else "Average match" if s >= 5 else "Worst match"


def style_header(ws, row, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = HEAD_FONT
        cell.fill = HEAD_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER


def get_or_create_apps(path):
    if os.path.exists(path):
        wb = load_workbook(path)
        if "Applications" not in wb.sheetnames:
            sys.exit("Workbook has no 'Applications' sheet - is this the right file?")
        ws = wb["Applications"]
        for name in ("Dashboard", "Daily Log"):
            if name in wb.sheetnames:
                del wb[name]
        return wb, ws
    wb = Workbook()
    ws = wb.active
    ws.title = "Applications"
    for i, h in enumerate(APP_HEADERS, 1):
        ws.cell(row=1, column=i, value=h)
    style_header(ws, 1, len(APP_HEADERS))
    widths = [6, 28, 34, 18, 22, 18, 12, 16, 15, 34, 45, 36]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[chr(64 + i)].width = w
    ws.freeze_panes = "C2"
    return wb, ws


def last_data_row(ws):
    r = ws.max_row
    while r > 1 and ws.cell(row=r, column=2).value in (None, ""):
        r -= 1
    return r


def append_rows(ws, rows):
    r = last_data_row(ws)
    sno = int(ws.cell(row=r, column=1).value or 0) if r > 1 else 0
    for item in rows:
        r += 1
        sno += 1
        applied = item.get("applied_at")
        applied = datetime.fromisoformat(applied) if applied else now_ist()
        score = item.get("match_score")
        values = [sno, item.get("company", ""), item.get("role", ""), item.get("platform", ""),
                  applied, f"=INT(E{r}-TIME(4,0,0))", score, label_for(score),
                  item.get("status", "Applied"), item.get("resume_file", ""),
                  item.get("link", ""), item.get("notes", "")]
        for c, v in enumerate(values, 1):
            cell = ws.cell(row=r, column=c, value=v)
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=c in (2, 3, 10, 12))
        ws.cell(row=r, column=5).number_format = "dd-mmm-yyyy hh:mm AM/PM"
        ws.cell(row=r, column=6).number_format = "dd-mmm-yyyy ddd"
        link = item.get("link")
        if link:
            ws.cell(row=r, column=11).hyperlink = link
            ws.cell(row=r, column=11).font = Font(name=FONT, size=10, color="0563C1", underline="single")
    dv = DataValidation(type="list", formula1='"' + ",".join(STATUSES) + '"', allow_blank=True)
    ws.add_data_validation(dv)
    dv.add(f"I2:I{MAXR}")


def set_statuses(ws, updates):
    last = last_data_row(ws)
    for upd in updates:
        sno_s, _, status = upd.partition(":")
        found = False
        for r in range(2, last + 1):
            if str(ws.cell(row=r, column=1).value) == sno_s.strip():
                ws.cell(row=r, column=9, value=status.strip())
                found = True
        if not found:
            print(f"warning: S.No {sno_s} not found", file=sys.stderr)


def build_daily_log(wb):
    ws = wb.create_sheet("Daily Log")
    for i, h in enumerate(["Tracker Day", "Weekday", "Applications", "Status", "Streak"], 1):
        ws.cell(row=1, column=i, value=h)
    style_header(ws, 1, 5)
    apps_f = "Applications!$F$2:$F$%d" % MAXR
    apps_i = "Applications!$I$2:$I$%d" % MAXR
    for r in range(2, LOG_ROWS + 2):
        n = r - 2
        ws[f"A{r}"] = f'=IF(Dashboard!$B$5+{n}>Dashboard!$B$4,"",Dashboard!$B$5+{n})'
        ws[f"B{r}"] = f'=IF(A{r}="","",TEXT(A{r},"ddd"))'
        ws[f"C{r}"] = f'=IF(A{r}="","",COUNTIFS({apps_f},A{r},{apps_i},"<>Not submitted"))'
        ws[f"D{r}"] = (f'=IF(A{r}="","",IF(C{r}>0,"Applied",'
                       f'IF(A{r}=Dashboard!$B$4,"Pending today","Missed")))')
        ws[f"E{r}"] = (f'=IF(A{r}="","",IF(C{r}>0,1,0))' if r == 2 else
                       f'=IF(A{r}="","",IF(C{r}>0,N(E{r-1})+1,0))')
        ws[f"A{r}"].number_format = "dd-mmm-yyyy"
        for c in "ABCDE":
            ws[f"{c}{r}"].font = BODY_FONT
            ws[f"{c}{r}"].alignment = Alignment(horizontal="center")
    for col, w in zip("ABCDE", [16, 11, 14, 16, 9]):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"
    rng = f"D2:D{LOG_ROWS + 1}"
    ws.conditional_formatting.add(rng, FormulaRule(formula=['D2="Applied"'], fill=PatternFill("solid", bgColor="C6EFCE")))
    ws.conditional_formatting.add(rng, FormulaRule(formula=['D2="Missed"'], fill=PatternFill("solid", bgColor="FFC7CE")))
    ws.conditional_formatting.add(rng, FormulaRule(formula=['D2="Pending today"'], fill=PatternFill("solid", bgColor="FFEB9C")))
    return ws


def build_dashboard(wb):
    ws = wb.create_sheet("Dashboard", 0)
    ws["A1"] = "JobHunt Dashboard"
    ws["A1"].font = Font(name=FONT, size=16, bold=True, color="1F3A5F")
    ws["A2"] = ("A day runs 4:00 AM to 3:59 AM IST the next morning. Applications marked "
                "'Not submitted' are not counted. Everything here recalculates from the Applications sheet.")
    ws["A2"].font = Font(name=FONT, size=9, italic=True, color="666666")

    log = "'Daily Log'!"
    rngA, rngC, rngD, rngE = (f"{log}${c}$2:${c}${LOG_ROWS + 1}" for c in "ACDE")
    apps_f = "Applications!$F$2:$F$%d" % MAXR
    apps_i = "Applications!$I$2:$I$%d" % MAXR
    stats = [
        ("Today (tracker day)", "=INT(NOW()-TIME(4,0,0))", "dd-mmm-yyyy ddd"),
        ("Hunt started", f"=IF(COUNT({apps_f})=0,B4,MIN({apps_f}))", "dd-mmm-yyyy ddd"),
        ("Total applications", f'=COUNTIFS(Applications!$B$2:$B${MAXR},"<>",{apps_i},"<>Not submitted")', "0"),
        ("Applied today", f"=IFERROR(INDEX({rngC},MATCH(B4,{rngA},0)),0)", "0"),
        ("Days applied", f'=COUNTIF({rngD},"Applied")', "0"),
        ("Days missed", f'=COUNTIF({rngD},"Missed")', "0"),
        ("Consistency", "=IF(B8+B9=0,0,B8/(B8+B9))", "0%"),
        ("Current streak (days)",
         f"=IFERROR(IF(B7>0,INDEX({rngE},MATCH(B4,{rngA},0)),"
         f"IF(MATCH(B4,{rngA},0)>1,INDEX({rngE},MATCH(B4,{rngA},0)-1),0)),0)", "0"),
        ("Longest streak (days)", f"=MAX({rngE})", "0"),
        ("Best day (applications)", f"=MAX({rngC})", "0"),
        ("Avg per active day", "=IF(B8=0,0,B6/B8)", "0.0"),
    ]
    for i, (label, formula, fmt) in enumerate(stats):
        r = 4 + i
        ws[f"A{r}"] = label
        ws[f"B{r}"] = formula
        ws[f"A{r}"].font = Font(name=FONT, bold=True, size=10)
        ws[f"B{r}"].font = Font(name=FONT, size=10)
        ws[f"B{r}"].number_format = fmt
        ws[f"B{r}"].alignment = Alignment(horizontal="right")
        ws[f"A{r}"].border = ws[f"B{r}"].border = BORDER
    # stats occupy rows 4-14

    ws["A17"] = "Calendar: one row per week (Mon-Sun). Red = missed day, amber = today (not applied yet), green = applied (darker = 3+)."
    ws["A17"].font = Font(name=FONT, bold=True, size=10)
    for i, h in enumerate(["Week of (Mon)", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "Week total"], 1):
        ws.cell(row=18, column=i, value=h)
    style_header(ws, 18, 9)
    first, last = 19, 19 + WEEKS - 1
    for r in range(first, last + 1):
        ws[f"A{r}"] = "=B5-WEEKDAY(B5,2)+1" if r == first else f"=A{r-1}+7"
        ws[f"A{r}"].number_format = "dd-mmm-yyyy"
        for off in range(7):
            col = chr(ord("B") + off)
            ws[f"{col}{r}"] = (f'=IF(OR($A{r}+{off}<$B$5,$A{r}+{off}>$B$4),"",'
                               f'COUNTIFS({apps_f},$A{r}+{off},{apps_i},"<>Not submitted"))')
            ws[f"{col}{r}"].alignment = Alignment(horizontal="center")
            ws[f"{col}{r}"].border = BORDER
            ws[f"{col}{r}"].font = BODY_FONT
        ws[f"I{r}"] = f'=IF(A{r}>$B$4,"",SUM(B{r}:H{r}))'
        ws[f"I{r}"].alignment = Alignment(horizontal="center")
        for c in "AI":
            ws[f"{c}{r}"].font = BODY_FONT
            ws[f"{c}{r}"].border = BORDER
    grid = f"B{first}:H{last}"
    date_expr = f"$A{first}+COLUMN(B{first})-2"
    ws.conditional_formatting.add(grid, FormulaRule(formula=[f"AND(ISNUMBER(B{first}),B{first}=0,{date_expr}<$B$4)"], fill=PatternFill("solid", bgColor="FFC7CE")))
    ws.conditional_formatting.add(grid, FormulaRule(formula=[f"AND(ISNUMBER(B{first}),B{first}=0,{date_expr}=$B$4)"], fill=PatternFill("solid", bgColor="FFEB9C")))
    ws.conditional_formatting.add(grid, FormulaRule(formula=[f"AND(ISNUMBER(B{first}),B{first}>=3)"], fill=PatternFill("solid", bgColor="63BE7B"), stopIfTrue=True))
    ws.conditional_formatting.add(grid, FormulaRule(formula=[f"AND(ISNUMBER(B{first}),B{first}>=1)"], fill=PatternFill("solid", bgColor="C6EFCE")))

    ws.column_dimensions["A"].width = 26
    for c in "BCDEFGH":
        ws.column_dimensions[c].width = 9
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["I"].width = 12

    chart = BarChart()
    chart.type = "col"
    chart.title = "Applications per week"
    chart.y_axis.title = "Applications"
    chart.x_axis.title = "Week of (Mon)"
    chart.add_data(Reference(ws, min_col=9, min_row=18, max_row=last), titles_from_data=True)
    chart.set_categories(Reference(ws, min_col=1, min_row=first, max_row=last))
    chart.legend = None
    chart.height, chart.width = 8, 22
    chart.x_axis.number_format = "dd-mmm"
    chart.x_axis.delete = False
    chart.y_axis.delete = False
    ws.add_chart(chart, "K4")
    ws.sheet_view.showGridLines = False
    return ws


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    ap.add_argument("--add", help="JSON file with new application rows")
    ap.add_argument("--set-status", action="append", default=[], help='"S.No:Status"')
    args = ap.parse_args()

    wb, ws = get_or_create_apps(args.file)
    if args.add:
        with open(args.add) as f:
            append_rows(ws, json.load(f))
    if args.set_status:
        set_statuses(ws, args.set_status)
    build_daily_log(wb)
    build_dashboard(wb)
    wb.move_sheet("Applications", offset=0)
    wb._sheets = [wb["Dashboard"], wb["Applications"], wb["Daily Log"]]
    wb.active = 0
    os.makedirs(os.path.dirname(os.path.abspath(args.file)), exist_ok=True)
    wb.save(args.file)
    print(f"saved {args.file} ({last_data_row(ws) - 1} application rows)")


if __name__ == "__main__":
    main()
